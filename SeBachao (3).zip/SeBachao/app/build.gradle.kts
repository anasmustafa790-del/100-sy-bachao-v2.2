import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sebachao.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sebachao.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the release APK is directly installable.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("io.coil-kt:coil-gif:2.6.0")
}

// ---------------------------------------------------------------------------------------------
// Fonts: Bangers, Lilita One and Fredoka are downloaded into the app's assets before every build,
// so they are bundled INSIDE the APK and look the same on every phone (no internet needed later).
// Already-downloaded fonts are kept. Several mirrors are tried.
// ---------------------------------------------------------------------------------------------
val downloadFonts by tasks.registering {
    val dir = file("src/main/assets/fonts")
    doLast {
        dir.mkdirs()
        val hosts = listOf(
            "https://raw.githubusercontent.com/google/fonts/main/ofl",
            "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl",
            "https://github.com/google/fonts/raw/main/ofl"
        )
        val fonts = linkedMapOf(
            "bangers.ttf" to listOf("bangers/Bangers-Regular.ttf"),
            "lilitaone.ttf" to listOf("lilitaone/LilitaOne-Regular.ttf"),
            "fredoka.ttf" to listOf(
                "fredoka/Fredoka%5Bwdth%2Cwght%5D.ttf",
                "fredoka/Fredoka-VariableFont_wdth%2Cwght.ttf"
            )
        )
        for ((name, paths) in fonts) {
            val out = File(dir, name)
            if (out.exists() && out.length() > 10000) continue
            var ok = false
            for (host in hosts) {
                for (path in paths) {
                    if (ok) break
                    try {
                        URL("$host/$path").openStream().use { input ->
                            out.outputStream().use { output -> input.copyTo(output) }
                        }
                        if (out.length() > 10000) ok = true else out.delete()
                    } catch (e: Exception) {
                        out.delete()
                    }
                }
                if (ok) break
            }
            if (!ok) logger.warn("WARNING: could not download font $name - that style will use the default font")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadFonts) }
