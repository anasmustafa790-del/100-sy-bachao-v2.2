#!/usr/bin/env bash
# Downloads the three Google Fonts used by the app into app/src/main/assets/fonts/
# (needed only if you build locally in Android Studio; GitHub Actions does this automatically).
set -u
d="$(dirname "$0")/app/src/main/assets/fonts"
mkdir -p "$d"
hosts="https://raw.githubusercontent.com/google/fonts/main/ofl https://cdn.jsdelivr.net/gh/google/fonts@main/ofl https://github.com/google/fonts/raw/main/ofl"
get() { # name path...
  out="$d/$1"; shift
  for h in $hosts; do
    for p in "$@"; do
      if curl -fsSL --retry 3 -o "$out" "$h/$p" && [ "$(wc -c < "$out")" -gt 10000 ]; then echo "ok  $out"; return 0; fi
      rm -f "$out"
    done
  done
  echo "FAILED $out (app will use the default font for that style)"
}
get bangers.ttf   "bangers/Bangers-Regular.ttf"
get lilitaone.ttf "lilitaone/LilitaOne-Regular.ttf"
get fredoka.ttf   "fredoka/Fredoka%5Bwdth%2Cwght%5D.ttf" "fredoka/Fredoka-VariableFont_wdth%2Cwght.ttf"
