Fonts used by the app (all SIL Open Font License, from Google Fonts):
  bangers.ttf     Bangers        - big titles (100, NEW GAME, OUT!, WINS!)
  lilitaone.ttf   Lilita One     - buttons, labels, scores
  fredoka.ttf     Fredoka        - normal text

They are downloaded automatically by the GitHub Actions build (see .github/workflows/build-apk.yml).
For a local build run ./get_fonts.sh, or copy the three .ttf files here with exactly these names.
If a file is missing the app still works and uses the phone's default font for that style.
