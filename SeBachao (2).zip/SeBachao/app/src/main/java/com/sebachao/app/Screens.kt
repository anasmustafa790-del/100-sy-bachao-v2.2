package com.sebachao.app

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.zIndex
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen(
    vm: GameViewModel,
    state: GameState,
    onPickImage: (String) -> Unit,
    onNewGame: () -> Unit,
    onSettings: () -> Unit
) {
    var showRound by remember { mutableStateOf(false) }
    var historyId by remember { mutableStateOf<Int?>(null) }
    var elimNames by remember { mutableStateOf<List<String>?>(null) }
    var showWinner by remember { mutableStateOf(false) }
    var pendingWinner by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is GameEvent.Eliminated -> elimNames = e.names
                is GameEvent.Won, is GameEvent.Draw -> if (elimNames != null) pendingWinner = true else showWinner = true
                is GameEvent.Message -> {}
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            BottomBar(
                state,
                onAdd = { showRound = true },
                onNew = onNewGame,
                onWinner = { showWinner = true }
            )
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 14.dp, end = 14.dp,
                top = pad.calculateTopPadding() + 4.dp,
                bottom = pad.calculateBottomPadding() + 16.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Header(state, onPickBanner = { onPickImage("banner") })
            }
            item(span = { GridItemSpan(maxLineSpan) }) { RoundBar(state, onSettings) }
            itemsIndexed(state.players, key = { _, p -> p.id }) { index, p ->
                PlayerCard(
                    p = p,
                    out = state.isOut(p),
                    max = state.maxScore,
                    index = index,
                    barStyle = state.barStyle,
                    onPhoto = { onPickImage("p:${p.id}") },
                    onRename = { vm.rename(p.id, it) },
                    onHistory = { historyId = p.id }
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) { StatusFooter(state) }
        }
    }

    if (showRound) {
        RoundDialog(
            state = state,
            onDismiss = { showRound = false },
            onSubmit = { map ->
                val r = vm.addRound(state.round, map)
                if (r == null) showRound = false
                r
            }
        )
    }
    val hid = historyId
    if (hid != null && hid < state.roster.size) {
        HistoryDialog(state, state.roster[hid], onDismiss = { historyId = null })
    }
    val en = elimNames
    if (en != null) {
        EliminationDialog(state, en) {
            elimNames = null
            if (pendingWinner) {
                pendingWinner = false
                showWinner = true
            }
        }
    }
    if (showWinner && state.matchOver) {
        WinnerDialog(state, onClose = { showWinner = false }, onNewGame = {
            showWinner = false
            onNewGame()
        })
    }
}

@Composable
fun BottomBar(state: GameState, onAdd: () -> Unit, onNew: () -> Unit, onWinner: () -> Unit) {
    val over = state.matchOver
    val C = LocalColors.current
    val F = LocalFonts.current
    Surface(color = C(K.BOTTOM_BG), shadowElevation = 12.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = if (over) onWinner else onAdd,
                modifier = Modifier.weight(1.5f).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(3.dp, C(K.BTN_BORDER)),
                colors = ButtonDefaults.buttonColors(containerColor = C(K.BTN_BG), contentColor = C(K.BTN_TEXT))
            ) {
                Text(
                    if (!over) "ADD ROUND" else if (state.isDraw) "RESULT" else "WINNER",
                    fontFamily = F.heading, fontSize = 22.sp
                )
            }
            Button(
                onClick = onNew,
                modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(3.dp, C(K.BTN2_BORDER)),
                colors = ButtonDefaults.buttonColors(containerColor = C(K.BTN2_BG), contentColor = C(K.BTN2_TEXT)),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) { Text("NEW GAME", fontFamily = F.heading, fontSize = 18.sp, maxLines = 1) }
        }
    }
}

/** Header sticker sizes. The total header height now comes from Settings (state.headerH). */
object HeaderSpec {
    val sticker1W = 140.dp        // left sticker box
    val sticker2W = 96.dp         // right sticker box
    val stickerH = 214.dp         // both sticker boxes (max)
    val stickerGap = 10.dp        // space between the two stickers
}

@Composable
fun Header(state: GameState, onPickBanner: () -> Unit) {
    val C = LocalColors.current
    val bmp = rememberBitmap(state.banner)
    val shape = RoundedCornerShape(22.dp)
    val digits = state.maxScore.toString().length
    val numSize = when {
        digits <= 2 -> 96.sp
        digits == 3 -> 86.sp
        else -> 62.sp
    }
    val total = state.headerH.dp
    val body = total * (176f / 222f)
    val stickerH = (total - 8.dp).coerceAtMost(HeaderSpec.stickerH)
    BoxWithConstraints(Modifier.fillMaxWidth().height(total).zIndex(1f)) {
        val k = (maxWidth / 360.dp).coerceIn(0.8f, 1.15f)
        // banner
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(body)
                .clip(shape)
                .background(Brush.linearGradient(listOf(C(K.HDR_FROM), C(K.HDR_TO))))
                .border(4.dp, C(K.HDR_BORDER), shape)
                .clickable(onClick = onPickBanner)
        ) {
            if (bmp != null) {
                Image(
                    bitmap = bmp, contentDescription = "Header banner",
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
                Box(Modifier.fillMaxSize().background(Color(0x66000000)))
            }
        }
        // stickers (each one can be moved / resized in Settings > Customize header)
        if (state.stickersOn) {
            Row(
                Modifier.align(Alignment.BottomEnd).padding(end = 8.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(HeaderSpec.stickerGap * k)
            ) {
                Tweak("h_s1") {
                    StickerView(
                        state, Slot.HEAD1,
                        Modifier.size(width = HeaderSpec.sticker1W * k, height = stickerH * k).wiggle(1300, 4f)
                    )
                }
                Tweak("h_s2") {
                    StickerView(
                        state, Slot.HEAD2,
                        Modifier.size(width = HeaderSpec.sticker2W * k, height = stickerH * k).wiggle(1300, 4f, 350)
                    )
                }
            }
        }
        // text sits on top of the stickers so it always stays readable
        Box(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().height(body),
            contentAlignment = Alignment.CenterStart
        ) {
            Column(Modifier.padding(start = 14.dp)) {
                Tweak("h_num") { OutlineText("${state.maxScore}", numSize, C(K.HDR_NUMBER)) }
                Tweak("h_title", Modifier.offset(y = (-8).dp)) {
                    OutlineText("SE BACHAO!", 32.sp, C(K.HDR_TITLE), outline = 2.dp)
                }
            }
        }
    }
}

@Composable
fun RoundBar(state: GameState, onSettings: () -> Unit) {
    val C = LocalColors.current
    val F = LocalFonts.current
    val shape = RoundedCornerShape(16.dp)
    Box(Modifier.fillMaxWidth()) {
        Box(Modifier.matchParentSize().offset(4.dp, 4.dp).background(Color.Black, shape))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(C(K.ROUND_BG))
                .border(3.dp, C(K.ROUND_BORDER), shape)
                .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (state.matchOver) "MATCH OVER" else "ROUND ${state.round}",
                    color = C(K.ROUND_TITLE), fontSize = 28.sp, fontFamily = F.display
                )
                Text(
                    "${state.roundsPlayed} played  •  ${state.active.size} of ${state.count} alive",
                    color = C(K.ROUND_TEXT), fontSize = 12.sp
                )
            }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(C(K.GEAR_BG))
                    .border(3.dp, C(K.GEAR_BORDER), CircleShape)
                    .clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = C(K.GEAR_ICON), fontSize = 24.sp) }
        }
    }
}

@Composable
fun StatusFooter(state: GameState) {
    val w = state.winner
    val C = LocalColors.current
    val text = when {
        w != null -> "🏆 ${w.displayName} wins the match!"
        state.isDraw -> "🤝 Everyone's out. No winner this time!"
        state.roundsPlayed == 0 -> "No rounds yet. Tap ADD ROUND to deal the first hand!"
        else -> "Still alive: " + state.active.joinToString { it.displayName }
    }
    Text(
        text, color = C(K.TEXT), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center
    )
}

@Composable
fun StatusChip(out: Boolean, modifier: Modifier = Modifier) {
    val C = LocalColors.current
    Text(
        if (out) "OUT" else "ACTIVE",
        color = if (out) Color.White else Color(0xFF06210F),
        fontFamily = LocalFonts.current.heading, fontSize = 12.sp,
        modifier = modifier
            .background(if (out) C(K.OUT_COLOR) else C(K.CHIP_ACTIVE), RoundedCornerShape(50))
            .border(2.dp, Color.Black, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 2.dp)
    )
}

@Composable
fun PlayerCard(
    p: Player,
    out: Boolean,
    max: Int,
    index: Int,
    barStyle: Int,
    onPhoto: () -> Unit,
    onRename: (String) -> Unit,
    onHistory: () -> Unit
) {
    val C = LocalColors.current
    val F = LocalFonts.current
    val shape = RoundedCornerShape(20.dp)
    val stamp by animateFloatAsState(
        if (out) 1f else 3f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "stamp"
    )
    val animScore by animateIntAsState(p.total, tween(700), label = "score")
    var text by remember(p.id) { mutableStateOf(p.name) }
    val frac = (p.total / max.toFloat()).coerceIn(0f, 1f)
    val outColor = C(K.OUT_COLOR)
    val barColor = when {
        out -> outColor
        frac >= 0.8f -> outColor
        frac >= 0.6f -> Color(0xFFFFC83D)
        else -> C(K.CHIP_ACTIVE)
    }
    BoxWithConstraints(Modifier.fillMaxWidth().graphicsLayer { rotationZ = if (index % 2 == 0) -1.2f else 1.2f }) {
        // big player photo: fills the card width (was a fixed 96.dp)
        val photoSize: Dp = (maxWidth - 28.dp).coerceIn(84.dp, 148.dp)
        Box(Modifier.matchParentSize().offset(5.dp, 5.dp).background(Color.Black, shape))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(if (out) lerp(C(K.CARD_BG), outColor, 0.18f) else C(K.CARD_BG))
                .border(3.dp, if (out) outColor else C(K.CARD_BORDER), shape)
        ) {
            Column(
                Modifier.padding(10.dp).alpha(if (out) 0.55f else 1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(
                    p.photo, p.id, photoSize, Modifier.clickable(onClick = onPhoto),
                    showBadge = true, ringWidth = 5.dp
                )
                StatusChip(out, Modifier.offset(y = (-12).dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it.take(14); onRename(text) },
                        singleLine = true,
                        textStyle = TextStyle(
                            color = C(K.CARD_NAME), fontFamily = F.body, fontWeight = FontWeight.Bold,
                            fontSize = 17.sp, textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(C(K.CARD_SCORE)),
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    "$animScore",
                    color = if (out) outColor else C(K.CARD_SCORE), fontSize = 46.sp,
                    fontFamily = F.heading, fontStyle = FontStyle.Italic
                )
                ScoreBar(barStyle, frac, barColor)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onHistory,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(3.dp, C(K.HIST_BORDER)),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C(K.HIST_BG), contentColor = C(K.HIST_TEXT))
                ) {
                    Text(
                        "History", color = C(K.HIST_TEXT), fontFamily = F.heading, fontSize = 16.sp,
                        maxLines = 1, overflow = TextOverflow.Clip
                    )
                }
            }
            if (out) {
                Text(
                    "OUT",
                    color = outColor, fontSize = 54.sp, fontFamily = F.display,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .graphicsLayer { rotationZ = -18f; scaleX = stamp; scaleY = stamp }
                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                        .border(5.dp, outColor, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                )
            }
        }
    }
}
