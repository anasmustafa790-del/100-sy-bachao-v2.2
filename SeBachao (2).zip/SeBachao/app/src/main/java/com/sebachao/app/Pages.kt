package com.sebachao.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.roundToInt

@Composable
fun PageTitle(title: String, sub: String, onBack: () -> Unit) {
    val C = LocalColors.current
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(C(K.GEAR_BG))
                    .border(3.dp, C(K.GEAR_BORDER), CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("‹", color = C(K.GEAR_ICON), fontSize = 28.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            OutlineText(title, 38.sp, C(K.PAGE_TITLE))
        }
        Spacer(Modifier.height(4.dp))
        Text(sub, color = C(K.TEXT), fontSize = 13.sp)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val C = LocalColors.current
    val shape = RoundedCornerShape(20.dp)
    Box(modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Box(Modifier.matchParentSize().offset(5.dp, 5.dp).background(Color.Black, shape))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(C(K.PANEL_BG))
                .border(3.dp, C(K.PANEL_BORDER), shape)
                .padding(14.dp),
            content = content
        )
    }
}

@Composable
fun PanelLabel(text: String) {
    val C = LocalColors.current
    Text(
        text, color = C(K.PANEL_LABEL), fontFamily = LocalFonts.current.heading,
        fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp)
    )
}

/** Main button (yellow by default) or, with secondary = true, the dark outlined button. */
@Composable
fun PopButton(
    text: String,
    modifier: Modifier = Modifier,
    secondary: Boolean = false,
    enabled: Boolean = true,
    height: Int = 50,
    onClick: () -> Unit
) {
    val C = LocalColors.current
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(height.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(3.dp, if (secondary) C(K.BTN2_BORDER) else C(K.BTN_BORDER)),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (secondary) C(K.BTN2_BG) else C(K.BTN_BG),
            contentColor = if (secondary) C(K.BTN2_TEXT) else C(K.BTN_TEXT)
        ),
        contentPadding = PaddingValues(horizontal = 12.dp)
    ) { Text(text, fontFamily = LocalFonts.current.heading, fontSize = 16.sp, maxLines = 1) }
}

@Composable
fun NewGameScreen(state: GameState, onStart: (Int, Int) -> Unit, onCancel: () -> Unit) {
    val C = LocalColors.current
    val F = LocalFonts.current
    var count by rememberSaveable { mutableStateOf(state.count) }
    var maxText by rememberSaveable { mutableStateOf(state.maxScore.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val max = maxText.toIntOrNull()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("NEW GAME", "Set up the match before you deal.", onCancel)
        Panel {
            PanelLabel("HOW MANY PLAYERS? ($MIN_PLAYERS TO $MAX_PLAYERS)")
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PopButton("−", Modifier.width(60.dp), height = 56) { if (count > MIN_PLAYERS) count-- }
                Text(
                    "$count", color = C(K.PANEL_LABEL), fontSize = 58.sp, fontFamily = F.display,
                    textAlign = TextAlign.Center, modifier = Modifier.width(100.dp)
                )
                PopButton("+", Modifier.width(60.dp), height = 56) { if (count < MAX_PLAYERS) count++ }
            }
            Spacer(Modifier.height(8.dp))
            for (rowPlayers in state.roster.take(count).chunked(6)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    for (p in rowPlayers) {
                        Avatar(p.photo, p.id, 40.dp, Modifier.padding(3.dp), ringWidth = 3.dp)
                    }
                }
            }
            Text(
                "Saved names and photos are kept. New players get default names.",
                color = C(K.TEXT), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        Panel {
            PanelLabel("MAX SCORE (OUT AT OR ABOVE)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (v in listOf(50, 100, 150, 200)) {
                    PopButton("$v", Modifier.weight(1f), secondary = max != v) {
                        maxText = v.toString(); error = null
                    }
                }
            }
            OutlinedTextField(
                value = maxText,
                onValueChange = { maxText = it.filter { c -> c.isDigit() }.take(4); error = null },
                singleLine = true,
                label = { Text("Custom max score") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            )
            Text(
                "Type any number from $MIN_LIMIT to $MAX_LIMIT.",
                color = C(K.TEXT), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Panel {
            Text(
                "$count players. Anyone reaching ${max ?: "?"} is OUT. Last one standing wins.",
                color = C(K.TEXT), fontSize = 13.sp
            )
        }
        val err = error
        if (err != null) {
            Text(err, color = Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
        }
        PopButton("START MATCH", Modifier.fillMaxWidth(), height = 56) {
            if (max == null || max < MIN_LIMIT || max > MAX_LIMIT) {
                error = "Max score must be between $MIN_LIMIT and $MAX_LIMIT."
            } else if (state.roundsPlayed > 0) {
                confirm = true
            } else {
                onStart(count, max)
            }
        }
        Spacer(Modifier.height(10.dp))
        PopButton("CANCEL", Modifier.fillMaxWidth(), secondary = true, height = 52) { onCancel() }
        Spacer(Modifier.height(16.dp))
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = C(K.DIALOG_BG),
            titleContentColor = C(K.DIALOG_TITLE),
            textContentColor = C(K.TEXT),
            title = { Text("New Game?", fontFamily = F.display, fontSize = 26.sp) },
            text = { Text("Start a new game? Current match scores and history will be cleared.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirm = false
                        onStart(count, max ?: DEFAULT_LIMIT)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = C(K.BTN_DANGER), contentColor = Color.White)
                ) { Text("Start New Game", fontFamily = F.heading) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Cancel", color = C(K.PANEL_BORDER)) }
            }
        )
    }
}

@Composable
private fun SoundRow(label: String, custom: Boolean, onPlay: () -> Unit, onPick: () -> Unit, onReset: () -> Unit) {
    val C = LocalColors.current
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, fontWeight = FontWeight.Bold, color = C(K.TEXT))
        Text(
            if (custom) "Custom MP3 selected (plays in full)" else "Default beep",
            color = C(K.PANEL_BORDER), fontSize = 12.sp
        )
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PopButton("Play", secondary = true, height = 38, onClick = onPlay)
            PopButton("Choose MP3", height = 38, onClick = onPick)
            PopButton("Reset", secondary = true, enabled = custom, height = 38, onClick = onReset)
        }
    }
}

@Composable
fun SettingsScreen(
    state: GameState,
    vm: GameViewModel,
    onPickSound: (String) -> Unit,
    onPickBanner: () -> Unit,
    onOpenStickers: () -> Unit,
    onOpenThemes: () -> Unit,
    onOpenColors: () -> Unit,
    onEditHeader: () -> Unit,
    onEditWinOut: () -> Unit,
    onBack: () -> Unit
) {
    val C = LocalColors.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("SETTINGS", "Sounds and looks. Everything stays offline.", onBack)
        Panel {
            PanelLabel("THEME & COLORS")
            Text(
                "Theme: ${themeById(state.themeId).name}" +
                    if (state.colors.isNotEmpty()) "  (+ ${state.colors.size} custom colours)" else "",
                fontWeight = FontWeight.Bold, color = C(K.TEXT)
            )
            Spacer(Modifier.height(10.dp))
            PopButton("CHOOSE THEME", Modifier.fillMaxWidth(), height = 52, onClick = onOpenThemes)
            Spacer(Modifier.height(8.dp))
            PopButton("CUSTOMIZE COLORS", Modifier.fillMaxWidth(), secondary = true, height = 52, onClick = onOpenColors)
        }
        Panel {
            PanelLabel("SOUNDS")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.soundOn, onCheckedChange = { vm.toggleSound() })
                Spacer(Modifier.width(10.dp))
                Text("Sound effects on", fontWeight = FontWeight.Bold, color = C(K.TEXT))
            }
            SoundRow("When a round is added", state.sounds.containsKey("add"),
                { vm.previewSound("add") }, { onPickSound("add") }, { vm.clearSound("add") })
            SoundRow("When a player is OUT", state.sounds.containsKey("out"),
                { vm.previewSound("out") }, { onPickSound("out") }, { vm.clearSound("out") })
            SoundRow("When someone wins", state.sounds.containsKey("win"),
                { vm.previewSound("win") }, { onPickSound("win") }, { vm.clearSound("win") })
        }
        Panel {
            PanelLabel("LOOK")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.stickersOn, onCheckedChange = { vm.toggleStickers() })
                Spacer(Modifier.width(10.dp))
                Text("Show stickers", fontWeight = FontWeight.Bold, color = C(K.TEXT))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PopButton("Header banner photo", Modifier.weight(1f), height = 40, onClick = onPickBanner)
                PopButton("Reset", secondary = true, enabled = state.banner != null, height = 40) { vm.clearBanner() }
            }
            Spacer(Modifier.height(10.dp))
            PopButton("EDIT ALL STICKERS", Modifier.fillMaxWidth(), height = 52, onClick = onOpenStickers)
        }
        Panel {
            PanelLabel("CUSTOMIZE LAYOUT")
            Text(
                "Open the real screen, then tap & hold anything to move it, drag the handle to resize it.",
                color = C(K.TEXT), fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            PopButton("CUSTOMIZE HEADER", Modifier.fillMaxWidth(), height = 52, onClick = onEditHeader)
            Spacer(Modifier.height(8.dp))
            PopButton("CUSTOMIZE WIN & OUT SCREENS", Modifier.fillMaxWidth(), height = 52, onClick = onEditWinOut)
        }
        Panel {
            PanelLabel("LOADING BAR STYLE")
            Text("Applies to every player's score bar.", color = C(K.TEXT), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            for ((i, name) in BarStyles.withIndex()) {
                val on = state.barStyle == i
                val shape = RoundedCornerShape(14.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(shape)
                        .background(if (on) C(K.PANEL_BORDER).copy(alpha = 0.22f) else Color.Transparent)
                        .border(if (on) 3.dp else 2.dp, if (on) C(K.PAGE_TITLE) else C(K.PANEL_BORDER).copy(alpha = 0.5f), shape)
                        .clickable { vm.setBarStyle(i) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(name, fontWeight = FontWeight.Bold, color = C(K.TEXT), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    ScoreBar(i, 0.65f, C(K.CHIP_ACTIVE))
                }
            }
        }
        Text("100 Se Bachao! v2.2", color = C(K.TEXT).copy(alpha = 0.6f), fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StickersScreen(
    state: GameState,
    vm: GameViewModel,
    onPickSticker: (String) -> Unit,
    onBack: () -> Unit
) {
    val C = LocalColors.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("STICKERS", "Pick an image or an animated GIF for each spot.", onBack)
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.stickersOn, onCheckedChange = { vm.toggleStickers() })
                Spacer(Modifier.width(10.dp))
                Text("Show stickers", fontWeight = FontWeight.Bold, color = C(K.TEXT))
            }
            Spacer(Modifier.height(6.dp))
            for (slot in Slot.values()) {
                val custom = state.stickers.containsKey(slot.key)
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(width = 64.dp, height = 72.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xAA000000))
                            .border(2.dp, C(K.PANEL_BORDER), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { StickerView(state, slot, Modifier.fillMaxSize().padding(2.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(slot.label, fontWeight = FontWeight.Bold, color = C(K.TEXT), fontSize = 14.sp)
                        Text(
                            if (custom) "Custom image / GIF" else "Default",
                            color = C(K.PANEL_BORDER), fontSize = 12.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PopButton("Change", height = 36) { onPickSticker(slot.key) }
                            PopButton("Reset", secondary = true, enabled = custom, height = 36) {
                                vm.clearSticker(slot.key)
                            }
                        }
                    }
                }
            }
        }
        Text("PNG, JPG, WEBP or GIF. A transparent PNG or GIF looks best.", color = C(K.TEXT), fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// THEMES
// ---------------------------------------------------------------------------------------------
@Composable
fun ThemesScreen(state: GameState, vm: GameViewModel, onBack: () -> Unit) {
    val C = LocalColors.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("THEMES", "Tap a theme and the whole app changes.", onBack)
        for (t in Themes) {
            val selected = t.id == state.themeId
            val p = t.palette
            val shape = RoundedCornerShape(18.dp)
            Box(Modifier.fillMaxWidth().padding(bottom = 14.dp).clickable { vm.setTheme(t.id) }) {
                Box(Modifier.matchParentSize().offset(4.dp, 4.dp).background(Color.Black, shape))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Brush.verticalGradient(listOf(p.bg1, p.bg2)))
                        .border(if (selected) 5.dp else 3.dp, if (selected) C(K.PAGE_TITLE) else p.border, shape)
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.name, color = p.accent, fontFamily = LocalFonts.current.display,
                            fontSize = 26.sp, modifier = Modifier.weight(1f)
                        )
                        if (selected) {
                            Text(
                                "✓ ACTIVE", color = p.onPrimary, fontFamily = LocalFonts.current.heading, fontSize = 12.sp,
                                modifier = Modifier
                                    .background(p.primary, RoundedCornerShape(50))
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    // mini preview: header strip + card + button
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(26.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.linearGradient(listOf(p.hdr1, p.hdr2)))
                            .border(2.dp, p.border, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "100 SE BACHAO!", color = p.accent, fontFamily = LocalFonts.current.display,
                            fontSize = 16.sp, modifier = Modifier.padding(start = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(p.surface)
                                .border(2.dp, p.border, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("Player 34", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        Box(
                            Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(p.primary)
                                .border(2.dp, Color.Black, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("ADD ROUND", color = p.onPrimary, fontFamily = LocalFonts.current.heading, fontSize = 13.sp) }
                    }
                }
            }
        }
        Text(
            "Choosing a theme also clears your custom colours. Pick the theme first, then fine-tune colours in CUSTOMIZE COLORS.",
            color = C(K.TEXT), fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// CUSTOMIZE COLORS
// ---------------------------------------------------------------------------------------------
private fun hexOf(c: Color): String {
    val v = c.toArgb()
    return "%02X%02X%02X".format((v shr 16) and 0xFF, (v shr 8) and 0xFF, v and 0xFF)
}

@Composable
fun ColorsScreen(state: GameState, vm: GameViewModel, onBack: () -> Unit) {
    val C = LocalColors.current
    var editing by remember { mutableStateOf<ColorKey?>(null) }
    val groups = remember { ColorKey.values().groupBy { it.group } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("COLORS", "Tap any colour box to change it.", onBack)
        Panel {
            Text(
                "Theme: ${themeById(state.themeId).name}. Every box below can be changed on its own " +
                    "and the whole app updates at once.",
                color = C(K.TEXT), fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            PopButton(
                "RESET ALL TO THEME", Modifier.fillMaxWidth(), secondary = true,
                enabled = state.colors.isNotEmpty(), height = 46
            ) { vm.resetColors() }
        }
        for ((group, keys) in groups) {
            Panel {
                PanelLabel(group)
                for (k in keys) {
                    val custom = C.isCustom(k)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { editing = k }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(C(k))
                                .border(3.dp, if (custom) C(K.PAGE_TITLE) else C(K.TEXT).copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(k.label, color = C(K.TEXT), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "#" + hexOf(C(k)) + if (custom) "  custom" else "  theme",
                                color = C(K.PANEL_BORDER), fontSize = 11.sp
                            )
                        }
                        if (custom) {
                            Text(
                                "↺", color = C(K.PAGE_TITLE), fontSize = 24.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable { vm.clearColor(k.key) }
                                    .padding(horizontal = 10.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    val k = editing
    if (k != null) {
        ColorPickerDialog(
            title = k.label,
            initial = C(k),
            isCustom = C.isCustom(k),
            onApply = { vm.setColor(k.key, it); editing = null },
            onReset = { vm.clearColor(k.key); editing = null },
            onDismiss = { editing = null }
        )
    }
}

private val PresetColors: List<Color> = listOf(
    0xFFFFFF, 0xF4F4F5, 0xA1A1AA, 0x52525B, 0x1A1A1A, 0x000000, 0x14040C, 0x3A1024,
    0xFF3B3B, 0xE8487F, 0xFF7AB6, 0xFF8AD8, 0xC084FC, 0x6D28D9, 0x1B4FB3, 0x38BDF8,
    0x5CC8FF, 0x2DD4BF, 0x39E58C, 0x3DDC84, 0xB6FF00, 0xFFE14D, 0xFFC83D, 0xFF9A3D,
    0xFF6B35, 0xC2410C, 0x8E1236, 0x7A5C00, 0x137A3E, 0x0F766E, 0x0B2A66, 0xFFF4DC
).map { Color(0xFF000000L or it.toLong()) }

@Composable
fun ColorPickerDialog(
    title: String,
    initial: Color,
    isCustom: Boolean,
    onApply: (Int) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val C = LocalColors.current
    val F = LocalFonts.current
    val start = initial.toArgb()
    var r by remember { mutableStateOf((start shr 16) and 0xFF) }
    var g by remember { mutableStateOf((start shr 8) and 0xFF) }
    var b by remember { mutableStateOf(start and 0xFF) }
    val current = Color(0xFF000000L or ((r shl 16) or (g shl 8) or b).toLong())
    var hex by remember(r, g, b) { mutableStateOf("%02X%02X%02X".format(r, g, b)) }

    fun setFrom(c: Color) {
        val v = c.toArgb()
        r = (v shr 16) and 0xFF
        g = (v shr 8) and 0xFF
        b = v and 0xFF
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f),
            shape = RoundedCornerShape(24.dp),
            color = C(K.DIALOG_BG), contentColor = C(K.TEXT),
            border = BorderStroke(3.dp, C(K.DIALOG_BORDER))
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text(title, color = C(K.DIALOG_TITLE), fontFamily = F.display, fontSize = 26.sp)
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(current)
                        .border(3.dp, C(K.TEXT), RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.height(8.dp))
                for (row in PresetColors.chunked(8)) {
                    Row(Modifier.fillMaxWidth()) {
                        for (pc in row) {
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(3.dp)
                                    .clip(CircleShape)
                                    .background(pc)
                                    .border(2.dp, C(K.TEXT).copy(alpha = 0.5f), CircleShape)
                                    .clickable { setFrom(pc) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                ChannelSlider("R", r, Color(0xFFFF5252)) { r = it }
                ChannelSlider("G", g, Color(0xFF4ADE80)) { g = it }
                ChannelSlider("B", b, Color(0xFF60A5FA)) { b = it }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { v ->
                        val clean = v.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }.take(6).uppercase()
                        hex = clean
                        if (clean.length == 6) {
                            val n = clean.toInt(16)
                            r = (n shr 16) and 0xFF
                            g = (n shr 8) and 0xFF
                            b = n and 0xFF
                        }
                    },
                    singleLine = true,
                    prefix = { Text("#") },
                    label = { Text("Hex colour") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PopButton("CANCEL", Modifier.weight(1f), secondary = true, height = 48, onClick = onDismiss)
                    PopButton("APPLY", Modifier.weight(1f), height = 48) { onApply(current.toArgb()) }
                }
                if (isCustom) {
                    Spacer(Modifier.height(8.dp))
                    PopButton("BACK TO THEME COLOUR", Modifier.fillMaxWidth(), secondary = true, height = 44, onClick = onReset)
                }
            }
        }
    }
}

@Composable
private fun ChannelSlider(label: String, value: Int, tint: Color, onChange: (Int) -> Unit) {
    val C = LocalColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontFamily = LocalFonts.current.heading, color = tint, modifier = Modifier.width(18.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt().coerceIn(0, 255)) },
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(
                thumbColor = tint, activeTrackColor = tint,
                inactiveTrackColor = C(K.TEXT).copy(alpha = 0.25f)
            ),
            modifier = Modifier.weight(1f)
        )
        Text("$value", color = C(K.TEXT), fontSize = 12.sp, modifier = Modifier.width(30.dp), textAlign = TextAlign.End)
    }
}
