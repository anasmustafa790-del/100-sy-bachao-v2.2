package com.sebachao.app

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val loader = remember {
                ImageLoader.Builder(ctx)
                    .components {
                        if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
                    }
                    .build()
            }
            val st by vm.state.collectAsState()
            SeBachaoTheme(st.themeId, st.colors) {
                CompositionLocalProvider(LocalLoader provides loader) {
                    AppRoot(vm)
                }
            }
        }
    }
}

@Composable
fun AppRoot(vm: GameViewModel) {
    val state by vm.state.collectAsState()
    val loaded by vm.loaded.collectAsState()
    var page by rememberSaveable { mutableStateOf("main") }
    var pendingImage by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingSound by rememberSaveable { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val t = pendingImage
        if (uri != null && t != null) {
            when {
                t == "banner" -> vm.setImage(-1, uri)
                t.startsWith("p:") -> {
                    val id = t.substring(2).toIntOrNull()
                    if (id != null) vm.setImage(id, uri)
                }
                t.startsWith("s:") -> vm.setSticker(t.substring(2), uri)
                t.startsWith("bg:") -> vm.setBgImage(t.substring(3), uri)
            }
        }
        pendingImage = null
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val k = pendingSound
        if (uri != null && k != null) vm.setSound(k, uri)
        pendingSound = null
    }
    fun pickImage(target: String) {
        pendingImage = target
        imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    fun pickSound(kind: String) {
        pendingSound = kind
        audioPicker.launch(arrayOf("audio/*"))
    }

    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            if (e is GameEvent.Message) snackbar.showSnackbar(e.text)
        }
    }
    BackHandler(enabled = page != "main") {
        page = if (page == "stickers" || page == "themes" || page == "colors" ||
            page == "edit_header" || page == "edit_winout"
        ) "settings" else "main"
    }

    val C = LocalColors.current
    CompositionLocalProvider(LocalTweaks provides TweakCtx(state.layout)) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(C(K.BG_TOP), C(K.BG_BOTTOM))))) {
        BackgroundDeco()
        if (!loaded) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = C(K.PAGE_TITLE))
                Spacer(Modifier.height(12.dp))
                Text("Shuffling the deck…", color = C(K.TEXT))
            }
        } else {
            when (page) {
                "setup" -> NewGameScreen(
                    state,
                    onStart = { c, m ->
                        vm.newGame(c, m)
                        page = "main"
                    },
                    onCancel = { page = "main" }
                )
                "settings" -> SettingsScreen(
                    state, vm,
                    onPickSound = { pickSound(it) },
                    onPickBanner = { pickImage("banner") },
                    onOpenStickers = { page = "stickers" },
                    onOpenThemes = { page = "themes" },
                    onOpenColors = { page = "colors" },
                    onEditHeader = { page = "edit_header" },
                    onEditWinOut = { page = "edit_winout" },
                    onBack = { page = "main" }
                )
                "edit_header" -> LayoutEditorScreen(
                    "header", state, vm,
                    onPickBg = { },
                    onDone = { page = "settings" }
                )
                "edit_winout" -> LayoutEditorScreen(
                    "winout", state, vm,
                    onPickBg = { pickImage("bg:$it") },
                    onDone = { page = "settings" }
                )
                "themes" -> ThemesScreen(state, vm, onBack = { page = "settings" })
                "colors" -> ColorsScreen(state, vm, onBack = { page = "settings" })
                "stickers" -> StickersScreen(
                    state, vm,
                    onPickSticker = { pickImage("s:$it") },
                    onBack = { page = "settings" }
                )
                else -> MainScreen(
                    vm, state,
                    onPickImage = { pickImage(it) },
                    onNewGame = { page = "setup" },
                    onSettings = { page = "settings" }
                )
            }
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp))
    }
    }
}
