package com.sebachao.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val MAX_PLAYERS = 12
const val MIN_PLAYERS = 2
const val DEFAULT_LIMIT = 100
const val MIN_LIMIT = 10
const val MAX_LIMIT = 9999

/** Position (dp offset from the normal place) and size multiplier of a movable screen element. */
data class ElemPos(val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f)

data class Entry(val round: Int, val score: Int)

data class Player(
    val id: Int,
    val name: String,
    val photo: String? = null,
    val history: List<Entry> = emptyList()
) {
    val total: Int get() = history.sumOf { it.score }
    val displayName: String get() = name.trim().ifBlank { "Player ${id + 1}" }
}

/** Every place in the app that shows a sticker. Each can be replaced by the user (image or GIF). */
enum class Slot(val key: String, val label: String, val res: Int) {
    HEAD1("head1", "Header sticker 1", R.drawable.st_duo),
    HEAD2("head2", "Header sticker 2", R.drawable.st_paisley),
    OUT("out", "OUT screen", R.drawable.st_lingerie),
    WIN_L("winl", "WIN screen - left", R.drawable.st_redgun),
    WIN_C("winc", "WIN screen - center", R.drawable.st_water),
    WIN_R("winr", "WIN screen - right", R.drawable.st_denim)
}

data class GameState(
    val roster: List<Player> = List(MAX_PLAYERS) { Player(it, "Player ${it + 1}") },
    val count: Int = 6,
    val maxScore: Int = DEFAULT_LIMIT,
    val round: Int = 1,
    val banner: String? = null,
    val soundOn: Boolean = true,
    val stickersOn: Boolean = true,
    val stickers: Map<String, String> = emptyMap(),
    val sounds: Map<String, String> = emptyMap(),
    val themeId: String = "velvet",
    /** Custom colours picked by the user: ColorKey.key -> ARGB int. They win over the theme. */
    val colors: Map<String, Int> = emptyMap(),
    /** Moved / resized elements (header, WIN screen, OUT screen). Key = id from TweakLabels. */
    val layout: Map<String, ElemPos> = emptyMap(),
    /** Total header height in dp (banner + room for the stickers). */
    val headerH: Float = 222f,
    /** Loading bar style under the scores: 0 = classic, 1..6 = funny styles. */
    val barStyle: Int = 0,
    /** Background of the WIN / OUT screen: -1 = theme, 0..9 = preset. A gallery photo wins over both. */
    val winBg: Int = -1,
    val outBg: Int = -1,
    val winBgImg: String? = null,
    val outBgImg: String? = null
) {
    val players: List<Player> get() = roster.take(count)
    fun isOut(p: Player): Boolean = p.total >= maxScore
    fun outRound(p: Player): Int? {
        var s = 0
        for (e in p.history) {
            s += e.score
            if (s >= maxScore) return e.round
        }
        return null
    }
    val active: List<Player> get() = players.filter { !isOut(it) }
    val roundsPlayed: Int get() = round - 1
    val matchOver: Boolean get() = roundsPlayed > 0 && active.size <= 1
    val winner: Player? get() = if (matchOver && active.size == 1) active[0] else null
    val isDraw: Boolean get() = matchOver && active.isEmpty()
}

/** Local, offline persistence (SharedPreferences + JSON). Survives app restarts and reboots. */
class Repo(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("se_bachao_store_v2", Context.MODE_PRIVATE)

    private fun mapToJson(m: Map<String, String>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        return o
    }

    private fun jsonToMap(o: JSONObject?): Map<String, String> {
        if (o == null) return emptyMap()
        val r = mutableMapOf<String, String>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = o.optString(k, "")
            if (v.isNotBlank()) r[k] = v
        }
        return r
    }

    private fun colorsToJson(m: Map<String, Int>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        return o
    }

    private fun jsonToColors(o: JSONObject?): Map<String, Int> {
        if (o == null) return emptyMap()
        val valid = ColorKey.values().map { it.key }.toSet()
        val r = mutableMapOf<String, Int>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in valid && o.has(k)) r[k] = o.optInt(k)
        }
        return r
    }

    private fun layoutToJson(m: Map<String, ElemPos>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) {
            o.put(k, JSONObject().put("x", v.x.toDouble()).put("y", v.y.toDouble()).put("s", v.scale.toDouble()))
        }
        return o
    }

    private fun jsonToLayout(o: JSONObject?): Map<String, ElemPos> {
        if (o == null) return emptyMap()
        val r = mutableMapOf<String, ElemPos>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val po = o.optJSONObject(k)
            if (k in TweakIds && po != null) {
                r[k] = ElemPos(
                    po.optDouble("x", 0.0).toFloat(),
                    po.optDouble("y", 0.0).toFloat(),
                    po.optDouble("s", 1.0).toFloat().coerceIn(0.2f, 4f)
                )
            }
        }
        return r
    }

    fun save(g: GameState) {
        val arr = JSONArray()
        for (p in g.roster) {
            val h = JSONArray()
            for (e in p.history) h.put(JSONObject().put("r", e.round).put("s", e.score))
            arr.put(JSONObject().put("name", p.name).put("photo", p.photo ?: "").put("history", h))
        }
        val o = JSONObject()
            .put("players", arr)
            .put("count", g.count)
            .put("max", g.maxScore)
            .put("banner", g.banner ?: "")
            .put("sound", g.soundOn)
            .put("stickersOn", g.stickersOn)
            .put("stickers", mapToJson(g.stickers))
            .put("sounds", mapToJson(g.sounds))
            .put("theme", g.themeId)
            .put("colors", colorsToJson(g.colors))
            .put("layout", layoutToJson(g.layout))
            .put("headerH", g.headerH.toDouble())
            .put("barStyle", g.barStyle)
            .put("winBg", g.winBg)
            .put("outBg", g.outBg)
            .put("winBgImg", g.winBgImg ?: "")
            .put("outBgImg", g.outBgImg ?: "")
        prefs.edit().putString("state", o.toString()).apply()
    }

    fun load(): GameState {
        val raw = prefs.getString("state", null) ?: return GameState()
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("players")
            val roster = (0 until MAX_PLAYERS).map { i ->
                if (i >= arr.length()) {
                    Player(i, "Player ${i + 1}")
                } else {
                    val po = arr.getJSONObject(i)
                    val h = po.optJSONArray("history") ?: JSONArray()
                    val entries = (0 until h.length()).map { j ->
                        val e = h.getJSONObject(j)
                        Entry(e.getInt("r"), e.getInt("s"))
                    }
                    val photo: String? = po.optString("photo", "").ifBlank { null }
                    Player(i, po.optString("name", "Player ${i + 1}"), photo, entries)
                }
            }
            val maxRound = roster.flatMap { it.history }.maxOfOrNull { it.round } ?: 0
            val banner: String? = o.optString("banner", "").ifBlank { null }
            GameState(
                roster = roster,
                count = o.optInt("count", 6).coerceIn(MIN_PLAYERS, MAX_PLAYERS),
                maxScore = o.optInt("max", DEFAULT_LIMIT).coerceIn(MIN_LIMIT, MAX_LIMIT),
                round = maxRound + 1,
                banner = banner,
                soundOn = o.optBoolean("sound", true),
                stickersOn = o.optBoolean("stickersOn", true),
                stickers = jsonToMap(o.optJSONObject("stickers")),
                sounds = jsonToMap(o.optJSONObject("sounds")),
                themeId = themeById(o.optString("theme", "velvet")).id,
                colors = jsonToColors(o.optJSONObject("colors")),
                layout = jsonToLayout(o.optJSONObject("layout")),
                headerH = o.optDouble("headerH", 222.0).toFloat().coerceIn(150f, 300f),
                barStyle = o.optInt("barStyle", 0).coerceIn(0, BarStyles.size - 1),
                winBg = o.optInt("winBg", -1).coerceIn(-1, WinBgs.size - 1),
                outBg = o.optInt("outBg", -1).coerceIn(-1, OutBgs.size - 1),
                winBgImg = o.optString("winBgImg", "").ifBlank { null },
                outBgImg = o.optString("outBgImg", "").ifBlank { null }
            )
        } catch (e: Exception) {
            GameState()
        }
    }
}
