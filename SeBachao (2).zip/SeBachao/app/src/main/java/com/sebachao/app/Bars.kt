package com.sebachao.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.sin

/**
 * The loading bar under every player's score. style 0 = the original bar, 1..6 = the funny ones.
 * [classic] is the colour the original bar uses (green, gold or red depending on how close to OUT).
 */
@Composable
fun ScoreBar(style: Int, frac: Float, classic: Color, modifier: Modifier = Modifier) {
    val f = frac.coerceIn(0f, 1f)
    val time: State<Float>? = if (style == 1 || style == 6) rememberTime() else null
    val shape = if (style == 5) RoundedCornerShape(6.dp) else RoundedCornerShape(50)
    val tip = when (style) {
        1 -> "🍬"
        2 -> "⚡"
        4 -> if (f >= 0.8f) "💀" else ""
        5 -> "🔋"
        6 -> "🔥"
        else -> ""
    }
    val gold = Color(0xFFFFC83D)
    BoxWithConstraints(modifier.fillMaxWidth().height(14.dp)) {
        val w = maxWidth
        androidx.compose.foundation.layout.Box(
            Modifier
                .fillMaxSize()
                .clip(shape)
                .border(2.dp, Color.Black, shape)
                .background(Color(0x33FFFFFF))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val width = size.width
                val h = size.height
                val fw = width * f
                val r = CornerRadius(h / 2f, h / 2f)
                val t = time?.value ?: 0f
                when (style) {
                    1 -> clipRect(right = fw) {
                        drawRect(Color(0xFFFF5C8A))
                        val step = h * 1.8f
                        var x = -step * 2f + (t * 40f) % step
                        while (x < fw + step) {
                            val path = Path().apply {
                                moveTo(x, h)
                                lineTo(x + h, 0f)
                                lineTo(x + h + step / 2f, 0f)
                                lineTo(x + step / 2f, h)
                                close()
                            }
                            drawPath(path, Color.White)
                            x += step
                        }
                    }
                    2 -> {
                        drawRoundRect(Color(0xFF00F0FF), size = Size(fw, h), cornerRadius = r)
                        drawRoundRect(
                            Color(0x99FFFFFF), topLeft = Offset(h * 0.3f, h * 0.15f),
                            size = Size((fw - h * 0.6f).coerceAtLeast(0f), h * 0.25f),
                            cornerRadius = CornerRadius(h * 0.12f, h * 0.12f)
                        )
                    }
                    3, 5 -> {
                        val n = if (style == 3) 10 else 5
                        val gap = 3f
                        val bw = (width - gap * (n + 1)) / n
                        val lit = ceil(f * n - 0.0001f).toInt()
                        val c = when {
                            f >= 0.8f -> Red
                            style == 5 && f < 0.6f -> Green
                            else -> gold
                        }
                        for (i in 0 until n) {
                            if (i < lit) {
                                drawRoundRect(
                                    c, topLeft = Offset(gap + i * (bw + gap), gap),
                                    size = Size(bw, h - 2f * gap), cornerRadius = CornerRadius(3f, 3f)
                                )
                            }
                        }
                    }
                    4 -> drawRoundRect(
                        Brush.horizontalGradient(listOf(Green, gold, Red), startX = 0f, endX = width),
                        size = Size(fw, h), cornerRadius = r
                    )
                    6 -> drawRoundRect(
                        Brush.horizontalGradient(listOf(Red, Color(0xFFFF9A3D)), startX = 0f, endX = width),
                        size = Size(fw, h), cornerRadius = r,
                        alpha = 0.78f + 0.22f * sin(t * 7f)
                    )
                    else -> drawRoundRect(classic, size = Size(fw, h), cornerRadius = r)
                }
            }
        }
        if (tip.isNotEmpty() && f > 0.02f) {
            Text(tip, fontSize = 16.sp, modifier = Modifier.offset(x = w * f - 10.dp, y = (-5).dp))
        }
    }
}
