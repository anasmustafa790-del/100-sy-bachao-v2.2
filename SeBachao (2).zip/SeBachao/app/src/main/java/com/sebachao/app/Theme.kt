package com.sebachao.app

import android.content.res.AssetManager
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// ---------------------------------------------------------------------------------------------
// Fixed colors (not part of themes)
// ---------------------------------------------------------------------------------------------
val Cream = Color(0xFFFFF4DC)
val Dark = Color(0xFF1A1A1A)
val Red = Color(0xFFFF3B3B)
val Green = Color(0xFF39E58C)

// ---------------------------------------------------------------------------------------------
// Fonts
//
// The three fonts live in app/src/main/assets/fonts/ :
//   bangers.ttf    -> big cartoon titles   (100, NEW GAME, OUT!, WINS!)
//   lilitaone.ttf  -> buttons, labels, scores
//   fredoka.ttf    -> normal body text
// The GitHub Actions workflow downloads them automatically before building. If a file is missing
// the app still runs and just uses the phone's default font for that style.
// ---------------------------------------------------------------------------------------------
class AppFonts(val display: FontFamily, val heading: FontFamily, val body: FontFamily)

val LocalFonts = staticCompositionLocalOf { AppFonts(FontFamily.Default, FontFamily.Default, FontFamily.Default) }

@OptIn(ExperimentalTextApi::class)
fun loadFonts(am: AssetManager): AppFonts {
    fun has(path: String): Boolean = try {
        am.open(path).use { it.available() > 1024 }
    } catch (e: Exception) {
        false
    }

    // The same file is registered for every weight so Android never fakes a "bold" on top of it.
    fun family(path: String): FontFamily? {
        if (!has(path)) return null
        return try {
            FontFamily(
                listOf(400, 500, 600, 700, 800, 900).map { w ->
                    Font(path = path, assetManager = am, weight = FontWeight(w))
                }
            )
        } catch (e: Throwable) {
            null
        }
    }
    return AppFonts(
        display = family("fonts/bangers.ttf") ?: FontFamily.Default,
        heading = family("fonts/lilitaone.ttf") ?: FontFamily.Default,
        body = family("fonts/fredoka.ttf") ?: FontFamily.Default
    )
}

// ---------------------------------------------------------------------------------------------
// Palettes and themes
// ---------------------------------------------------------------------------------------------
data class Palette(
    val bg1: Color,        // page background (top)
    val bg2: Color,        // page background (bottom)
    val surface: Color,    // cards, panels, dialogs
    val border: Color,     // main border / highlight colour
    val onBorder: Color,   // text on top of the border colour (History button)
    val accent: Color,     // titles, numbers
    val text: Color,       // normal text
    val primary: Color,    // main buttons
    val onPrimary: Color,  // text on main buttons
    val hdr1: Color,       // header gradient start
    val hdr2: Color        // header gradient end
)

private fun hx(rgb: Long) = Color(0xFF000000L or rgb)

private fun pal(
    bg1: Long, bg2: Long, surface: Long, border: Long, onBorder: Long, accent: Long,
    text: Long, primary: Long, onPrimary: Long, hdr1: Long, hdr2: Long
) = Palette(
    hx(bg1), hx(bg2), hx(surface), hx(border), hx(onBorder), hx(accent),
    hx(text), hx(primary), hx(onPrimary), hx(hdr1), hx(hdr2)
)

class ThemeDef(val id: String, val name: String, val palette: Palette)

val Themes: List<ThemeDef> = listOf(
    ThemeDef(
        "velvet", "Velvet Red",
        pal(0x14040C, 0x2A0A1A, 0x3A1024, 0xFF7AB6, 0x1A1A1A, 0xFFE14D, 0xFFE9F1, 0xFFC83D, 0x1A1A1A, 0x8E1236, 0x4A0A22)
    ),
    ThemeDef(
        "midnight", "Midnight Blue",
        pal(0x050B1F, 0x0B1A3D, 0x12264F, 0x5CC8FF, 0x06121F, 0xFFD84D, 0xE8F3FF, 0x38BDF8, 0x04121F, 0x1B4FB3, 0x0B2A66)
    ),
    ThemeDef(
        "casino", "Casino Green",
        pal(0x03140B, 0x0A2A18, 0x0F3B22, 0x3DDC84, 0x06210F, 0xFFE14D, 0xE9FFF1, 0xFFC83D, 0x1A1A1A, 0x137A3E, 0x074A25)
    ),
    ThemeDef(
        "purple", "Royal Purple",
        pal(0x0E0520, 0x22093F, 0x331459, 0xC084FC, 0x1A0B2E, 0xFFE14D, 0xF5EBFF, 0xFF8AD8, 0x2A0A3A, 0x6D28D9, 0x3B1280)
    ),
    ThemeDef(
        "sunset", "Sunset Orange",
        pal(0x1C0A02, 0x3A1405, 0x4D1E08, 0xFF9A3D, 0x1F0D02, 0xFFD23F, 0xFFF1E3, 0xFF6B35, 0x1A0A02, 0xC2410C, 0x7C2D12)
    ),
    ThemeDef(
        "ocean", "Ocean Teal",
        pal(0x02171A, 0x053438, 0x0A4A50, 0x2DD4BF, 0x03201F, 0xFFE066, 0xE6FFFC, 0x2DD4BF, 0x032221, 0x0F766E, 0x134E4A)
    ),
    ThemeDef(
        "gold", "Black & Gold",
        pal(0x0A0A0A, 0x1A1608, 0x241E0C, 0xF5C542, 0x1A1400, 0xF5C542, 0xFFF6DC, 0xF5C542, 0x1A1400, 0x7A5C00, 0x3D2E00)
    ),
    ThemeDef(
        "neon", "Neon Arcade",
        pal(0x07001A, 0x14003A, 0x1F0A52, 0x00F0FF, 0x00131A, 0xFF2E93, 0xF0F0FF, 0xB6FF00, 0x0A1A00, 0xFF2E93, 0x6A00F4)
    ),
    ThemeDef(
        "mono", "Steel Grey",
        pal(0x0B0B0D, 0x1B1B20, 0x26262D, 0xA1A1AA, 0x111111, 0xFAFAFA, 0xF4F4F5, 0xE4E4E7, 0x111111, 0x3F3F46, 0x18181B)
    ),
    ThemeDef(
        "blossom", "Cherry Blossom (light)",
        pal(0xFFF1F5, 0xFFD9E6, 0xFFFFFF, 0xE8487F, 0xFFFFFF, 0xC2185B, 0x3A1024, 0xE8487F, 0xFFFFFF, 0xF472A8, 0xE8487F)
    )
)

fun themeById(id: String): ThemeDef = Themes.firstOrNull { it.id == id } ?: Themes[0]

// ---------------------------------------------------------------------------------------------
// Every colour the user can change on its own. The default comes from the chosen theme; a custom
// value (saved in GameState.colors) wins over the theme.
// ---------------------------------------------------------------------------------------------
enum class ColorKey(val key: String, val label: String, val group: String, val def: (Palette) -> Color) {
    BG_TOP("bg_top", "Background - top", "BACKGROUND", { it.bg1 }),
    BG_BOTTOM("bg_bottom", "Background - bottom", "BACKGROUND", { it.bg2 }),

    HDR_FROM("hdr_from", "Header - gradient start", "HEADER", { it.hdr1 }),
    HDR_TO("hdr_to", "Header - gradient end", "HEADER", { it.hdr2 }),
    HDR_BORDER("hdr_border", "Header - border", "HEADER", { it.border }),
    HDR_NUMBER("hdr_number", "Header - big number", "HEADER", { it.accent }),
    HDR_TITLE("hdr_title", "Header - SE BACHAO text", "HEADER", { it.text }),

    ROUND_BG("round_bg", "Round bar - background", "ROUND BAR", { it.surface }),
    ROUND_BORDER("round_border", "Round bar - border", "ROUND BAR", { it.border }),
    ROUND_TITLE("round_title", "Round bar - ROUND title", "ROUND BAR", { it.accent }),
    ROUND_TEXT("round_text", "Round bar - small text", "ROUND BAR", { it.text }),
    GEAR_BG("gear_bg", "Settings button - background", "ROUND BAR", { it.bg1 }),
    GEAR_BORDER("gear_border", "Settings button - border", "ROUND BAR", { it.border }),
    GEAR_ICON("gear_icon", "Settings button - icon", "ROUND BAR", { it.accent }),

    CARD_BG("card_bg", "Player card - background", "PLAYER CARDS", { it.surface }),
    CARD_BORDER("card_border", "Player card - border", "PLAYER CARDS", { it.border }),
    PHOTO_RING("photo_ring", "Player photo - border", "PLAYER CARDS", { it.border }),
    CARD_NAME("card_name", "Player name - text", "PLAYER CARDS", { it.text }),
    CARD_SCORE("card_score", "Player score - number", "PLAYER CARDS", { it.accent }),
    HIST_BG("hist_bg", "History button - background", "PLAYER CARDS", { it.border }),
    HIST_TEXT("hist_text", "History button - text", "PLAYER CARDS", { it.onBorder }),
    HIST_BORDER("hist_border", "History button - border", "PLAYER CARDS", { Color.Black }),
    CHIP_ACTIVE("chip_active", "ACTIVE tag", "PLAYER CARDS", { Green }),
    OUT_COLOR("out_color", "OUT colour (stamp, tag, border)", "PLAYER CARDS", { Red }),

    BTN_BG("btn_bg", "Main buttons - background", "BUTTONS", { it.primary }),
    BTN_TEXT("btn_text", "Main buttons - text", "BUTTONS", { it.onPrimary }),
    BTN_BORDER("btn_border", "Main buttons - border", "BUTTONS", { Color.Black }),
    BTN2_BG("btn2_bg", "Second buttons - background", "BUTTONS", { it.bg1 }),
    BTN2_TEXT("btn2_text", "Second buttons - text", "BUTTONS", { it.text }),
    BTN2_BORDER("btn2_border", "Second buttons - border", "BUTTONS", { it.border }),
    BTN_DANGER("btn_danger", "Red button (NEW GAME on win screen)", "BUTTONS", { Red }),
    BOTTOM_BG("bottom_bg", "Bottom bar - background", "BUTTONS", { it.bg1 }),

    PAGE_TITLE("page_title", "Page titles (SETTINGS, NEW GAME)", "PANELS & TEXT", { it.accent }),
    PANEL_BG("panel_bg", "Panels - background", "PANELS & TEXT", { it.surface }),
    PANEL_BORDER("panel_border", "Panels - border", "PANELS & TEXT", { it.border }),
    PANEL_LABEL("panel_label", "Panels - heading text", "PANELS & TEXT", { it.accent }),
    TEXT("text", "Normal text", "PANELS & TEXT", { it.text }),

    DIALOG_BG("dialog_bg", "Pop-ups - background", "POP-UPS", { it.surface }),
    DIALOG_BORDER("dialog_border", "Pop-ups - border", "POP-UPS", { it.border }),
    DIALOG_TITLE("dialog_title", "Pop-ups - title", "POP-UPS", { it.accent }),

    SCREEN_ACCENT("screen_accent", "OUT / WIN screens - titles & rays", "POP-UPS", { it.accent })
}

typealias K = ColorKey

class AppColors(val p: Palette, private val overrides: Map<String, Int>) {
    operator fun invoke(k: ColorKey): Color {
        val v = overrides[k.key]
        return if (v != null) Color(v) else k.def(p)
    }

    fun isCustom(k: ColorKey): Boolean = overrides.containsKey(k.key)
}

val LocalColors = staticCompositionLocalOf { AppColors(Themes[0].palette, emptyMap()) }

private fun typographyOf(f: FontFamily): Typography {
    val b = Typography()
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = f),
        displayMedium = b.displayMedium.copy(fontFamily = f),
        displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f),
        headlineMedium = b.headlineMedium.copy(fontFamily = f),
        headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f),
        titleMedium = b.titleMedium.copy(fontFamily = f),
        titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f),
        bodyMedium = b.bodyMedium.copy(fontFamily = f),
        bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f),
        labelMedium = b.labelMedium.copy(fontFamily = f),
        labelSmall = b.labelSmall.copy(fontFamily = f)
    )
}

@Composable
fun SeBachaoTheme(themeId: String, overrides: Map<String, Int>, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val fonts = remember { loadFonts(ctx.assets) }
    val theme = themeById(themeId)
    val colors = remember(themeId, overrides) { AppColors(theme.palette, overrides) }
    val typo = remember(fonts) { typographyOf(fonts.body) }

    val bg = colors(K.BG_TOP)
    val text = colors(K.TEXT)
    val surface = colors(K.PANEL_BG)
    val primary = colors(K.BTN_BG)
    val onPrimary = colors(K.BTN_TEXT)
    val border = colors(K.PANEL_BORDER)
    val scheme = if (bg.luminance() > 0.5f) {
        lightColorScheme(
            primary = primary, onPrimary = onPrimary, secondary = border,
            background = bg, surface = surface, onSurface = text, onBackground = text,
            onSurfaceVariant = text.copy(alpha = 0.8f), outline = border, error = Red
        )
    } else {
        darkColorScheme(
            primary = primary, onPrimary = onPrimary, secondary = border,
            background = bg, surface = surface, onSurface = text, onBackground = text,
            onSurfaceVariant = text.copy(alpha = 0.8f), outline = border, error = Red
        )
    }

    CompositionLocalProvider(
        LocalColors provides colors,
        LocalFonts provides fonts,
        LocalContentColor provides text
    ) {
        MaterialTheme(colorScheme = scheme, typography = typo) {
            ProvideTextStyle(TextStyle(fontFamily = fonts.body)) { content() }
        }
    }
}
