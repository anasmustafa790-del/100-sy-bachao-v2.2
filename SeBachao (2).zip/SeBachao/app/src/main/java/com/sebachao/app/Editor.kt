package com.sebachao.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Full-screen layout editor.
 * kind = "header": the real header; kind = "winout": the real WIN and OUT screens (switch with the buttons).
 * Tap an element to select it. Press and hold, then drag = move it anywhere. Drag the round handle (or use
 * the size slider) = bigger / smaller.
 */
@Composable
fun LayoutEditorScreen(
    kind: String,
    state: GameState,
    vm: GameViewModel,
    onPickBg: (String) -> Unit,
    onDone: () -> Unit
) {
    val C = LocalColors.current
    val header = kind == "header"
    var tab by rememberSaveable { mutableStateOf("win") }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var open by rememberSaveable { mutableStateOf(true) }
    val sample = state.players.first()
    val screenIds = if (header) TweakLabels.keys.filter { it.startsWith("h_") }
    else TweakLabels.keys.filter { it.startsWith(if (tab == "win") "w_" else "o_") }
    val ctx = TweakCtx(
        layout = state.layout,
        editing = true,
        selected = selected,
        onSelect = { selected = it },
        onChange = { id, p -> vm.setLayoutLive(id, p) },
        onCommit = { vm.persistLayout() }
    )

    CompositionLocalProvider(LocalTweaks provides ctx) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(onTap = { selected = null }) }) {
                if (header) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                        PageTitle("HEADER", "Tap & hold an item, then drag it anywhere.", onDone)
                        Header(state, onPickBanner = {})
                        Spacer(Modifier.height(14.dp))
                        RoundBar(state, onSettings = {})
                        Spacer(Modifier.height(320.dp))
                    }
                } else if (tab == "win") {
                    WinnerBody(state, sample, onClose = {}, onNewGame = {}, bottomSpace = 320.dp)
                } else {
                    EliminationBody(state, listOf(sample.displayName), onDismiss = {}, bottomSpace = 320.dp)
                }
            }
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
                color = C(K.PANEL_BG),
                contentColor = C(K.TEXT),
                shadowElevation = 16.dp
            ) {
                Column(
                    Modifier
                        .heightIn(max = 330.dp)
                        .border(3.dp, C(K.PANEL_BORDER), RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (open) "▾ Hide tools" else "▴ Show tools",
                            color = C(K.PANEL_LABEL), fontFamily = LocalFonts.current.heading, fontSize = 15.sp,
                            modifier = Modifier.weight(1f).clickable { open = !open }.padding(vertical = 8.dp)
                        )
                        PopButton("DONE ✓", Modifier.width(120.dp), height = 42) {
                            vm.persistLayout()
                            onDone()
                        }
                    }
                    if (open) {
                        Text(
                            "Tap = select · press & hold, then drag = move · drag the ◢ handle = resize",
                            fontSize = 12.sp, color = C(K.TEXT).copy(alpha = 0.8f)
                        )
                        Spacer(Modifier.height(8.dp))
                        if (header) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Header height", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(104.dp))
                                Slider(
                                    value = state.headerH,
                                    onValueChange = { vm.setHeaderH(it) },
                                    onValueChangeFinished = { vm.persistLayout() },
                                    valueRange = 150f..300f,
                                    colors = SliderDefaults.colors(thumbColor = C(K.BTN_BG), activeTrackColor = C(K.BTN_BG)),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PopButton("WIN SCREEN", Modifier.weight(1f), secondary = tab != "win", height = 42) {
                                    tab = "win"; selected = null
                                }
                                PopButton("OUT SCREEN", Modifier.weight(1f), secondary = tab != "out", height = 42) {
                                    tab = "out"; selected = null
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            BgPicker(state, vm, win = tab == "win", onGallery = { onPickBg(tab) })
                        }
                        Spacer(Modifier.height(6.dp))
                        val sel = selected
                        val pos = if (sel != null) (state.layout[sel] ?: ElemPos()) else ElemPos()
                        if (sel != null && sel in screenIds) {
                            Text(
                                "Selected: ${TweakLabels[sel]}",
                                color = C(K.PANEL_LABEL), fontWeight = FontWeight.Bold, fontSize = 14.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Size", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(104.dp))
                                Slider(
                                    value = pos.scale,
                                    onValueChange = { vm.setLayoutLive(sel, pos.copy(scale = it)) },
                                    onValueChangeFinished = { vm.persistLayout() },
                                    valueRange = 0.2f..4f,
                                    colors = SliderDefaults.colors(thumbColor = C(K.BTN_BG), activeTrackColor = C(K.BTN_BG)),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            PopButton("RESET THIS ITEM", Modifier.fillMaxWidth(), secondary = true, height = 40) {
                                vm.resetLayout(listOf(sel))
                            }
                        } else {
                            Text("No item selected. Tap one on the screen above.", fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        PopButton("RESET WHOLE SCREEN", Modifier.fillMaxWidth(), secondary = true, height = 40) {
                            vm.resetLayout(screenIds)
                            if (header) {
                                vm.setHeaderH(222f)
                                vm.persistLayout()
                            }
                            selected = null
                        }
                    }
                }
            }
        }
    }
}

/** Row of backgrounds: theme default, 10 presets, and "my gallery photo". */
@Composable
private fun BgPicker(state: GameState, vm: GameViewModel, win: Boolean, onGallery: () -> Unit) {
    val C = LocalColors.current
    val kind = if (win) "win" else "out"
    val list = if (win) WinBgs else OutBgs
    val idx = if (win) state.winBg else state.outBg
    val img = if (win) state.winBgImg else state.outBgImg
    val shape = RoundedCornerShape(12.dp)
    @Composable
    fun Swatch(on: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
        Box(
            Modifier
                .size(56.dp)
                .clip(shape)
                .border(if (on) 4.dp else 2.dp, if (on) Color.White else Color.Black, shape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { content() }
    }
    Text(
        "BACKGROUND" + if (img != null) " (your photo)" else if (idx in list.indices) " (${list[idx].name})" else " (theme)",
        color = C(K.PANEL_LABEL), fontFamily = LocalFonts.current.heading, fontSize = 13.sp
    )
    Spacer(Modifier.height(4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Swatch(img == null && idx == -1, { vm.setBgPreset(kind, -1) }) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(C(K.BG_TOP), C(K.BG_BOTTOM)))))
            Text("🎨", fontSize = 22.sp)
        }
        for (i in list.indices) {
            Swatch(img == null && idx == i, { vm.setBgPreset(kind, i) }) {
                PresetBg(list[i], Modifier.fillMaxSize())
                Text(list[i].emoji, fontSize = 22.sp)
            }
        }
        Swatch(img != null, onGallery) {
            Box(Modifier.fillMaxSize().background(C(K.BTN_BG)))
            Text("📷", fontSize = 24.sp)
        }
    }
}
