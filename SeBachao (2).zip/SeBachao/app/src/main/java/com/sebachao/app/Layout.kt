package com.sebachao.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// Movable / resizable elements (header, WIN screen, OUT screen)
// ---------------------------------------------------------------------------------------------

/** Every element the user can move or resize, with the name shown in the editor. */
val TweakLabels: Map<String, String> = linkedMapOf(
    "h_num" to "Big number (100)",
    "h_title" to "SE BACHAO! text",
    "h_s1" to "Header sticker 1",
    "h_s2" to "Header sticker 2",
    "w_crown" to "Crown",
    "w_photo" to "Winner photo",
    "w_title" to "WINS! title",
    "w_bubble" to "Chat bubble",
    "w_sl" to "Sticker left",
    "w_sc" to "Sticker center",
    "w_sr" to "Sticker right",
    "w_scores" to "Final scores box",
    "w_btns" to "Bottom buttons",
    "o_title" to "OUT! title",
    "o_bubble" to "Chat bubble",
    "o_sticker" to "Sticker / GIF",
    "o_pill" to "Name card",
    "o_btn" to "RIP button"
)
val TweakIds: Set<String> = TweakLabels.keys

class TweakCtx(
    val layout: Map<String, ElemPos>,
    val editing: Boolean = false,
    val selected: String? = null,
    val onSelect: (String?) -> Unit = {},
    val onChange: (String, ElemPos) -> Unit = { _, _ -> },
    val onCommit: () -> Unit = {}
)

val LocalTweaks = compositionLocalOf { TweakCtx(emptyMap()) }

/**
 * Wraps one element. Normal mode: just applies the saved position / size.
 * Edit mode: tap = select, press and hold then drag = move anywhere, drag the round handle = resize.
 */
@Composable
fun Tweak(id: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val t = LocalTweaks.current
    val p = t.layout[id] ?: ElemPos()
    val move = Modifier.graphicsLayer {
        translationX = p.x * density
        translationY = p.y * density
        scaleX = p.scale
        scaleY = p.scale
    }
    if (!t.editing) {
        Box(modifier.then(move)) { content() }
        return
    }
    val cur by rememberUpdatedState(p)
    val ctx by rememberUpdatedState(t)
    val selected = t.selected == id
    var elSize by remember { mutableStateOf(IntSize(1, 1)) }
    val gold = Color(0xFFFFE14D)
    Box(modifier.then(move).onSizeChanged { elSize = it }) {
        content()
        Box(
            Modifier
                .matchParentSize()
                .background(if (selected) Color(0x22FFE14D) else Color.Transparent, RoundedCornerShape(8.dp))
                .border(if (selected) 3.dp else 1.dp, if (selected) gold else Color(0x99FFFFFF), RoundedCornerShape(8.dp))
                .pointerInput(id) { detectTapGestures(onTap = { ctx.onSelect(id) }) }
                .pointerInput(id) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { ctx.onSelect(id) },
                        onDragEnd = { ctx.onCommit() },
                        onDragCancel = { ctx.onCommit() },
                        onDrag = { change, d ->
                            change.consume()
                            val q = cur
                            ctx.onChange(
                                id,
                                q.copy(
                                    x = (q.x + d.x * q.scale / density).coerceIn(-700f, 700f),
                                    y = (q.y + d.y * q.scale / density).coerceIn(-900f, 900f)
                                )
                            )
                        }
                    )
                }
        )
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .graphicsLayer {
                        val s = 1f / cur.scale
                        scaleX = s
                        scaleY = s
                        transformOrigin = TransformOrigin(1f, 1f)
                    }
                    .size(36.dp)
                    .background(gold, CircleShape)
                    .border(3.dp, Color.Black, CircleShape)
                    .pointerInput(id) {
                        detectDragGestures(
                            onDragEnd = { ctx.onCommit() },
                            onDragCancel = { ctx.onCommit() },
                            onDrag = { change, d ->
                                change.consume()
                                val q = cur
                                val base = (elSize.width + elSize.height).toFloat().coerceAtLeast(1f) * q.scale
                                val f = 1f + (d.x + d.y) / base
                                ctx.onChange(id, q.copy(scale = (q.scale * f).coerceIn(0.2f, 4f)))
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) { Text("◢", color = Color.Black, fontSize = 15.sp) }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Loading bar styles (Settings > Loading bar style)
// ---------------------------------------------------------------------------------------------
val BarStyles = listOf(
    "Classic (green > red)",
    "Candy Stripes (moving)",
    "Neon Glow",
    "Block Meter",
    "Rainbow Danger",
    "Battery",
    "Hot Pulse"
)

// ---------------------------------------------------------------------------------------------
// Backgrounds for the WIN and OUT screens (10 each, plus the user's own gallery photo)
// ---------------------------------------------------------------------------------------------
/** kind: 0 vertical, 1 diagonal, 2 radial, 3 stripes (2 colours), 5 sweep */
class BgPreset(val name: String, val emoji: String, val kind: Int, val c: List<Color>)

private fun cols(vararg v: Long): List<Color> = v.map { Color(0xFF000000L or it) }

val WinBgs: List<BgPreset> = listOf(
    BgPreset("Party Confetti", "🎉", 1, cols(0x2A0A4A, 0xFF2E93, 0x27E1FF)),
    BgPreset("Rainbow Chaos", "🌈", 1, cols(0xFF3B3B, 0xFFC83D, 0x39E58C, 0x27E1FF, 0x8A2BE2)),
    BgPreset("Gold Rush", "💰", 2, cols(0xFFF3A0, 0xF5C542, 0x6B4A00)),
    BgPreset("Disco Night", "🪩", 5, cols(0xFF2E93, 0x6A00F4, 0x00F0FF, 0xFF2E93)),
    BgPreset("Money Rain", "💵", 0, cols(0x03280F, 0x0F7A3A)),
    BgPreset("Sunrise Baadshah", "👑", 0, cols(0xFF9A3D, 0xFF3B6B, 0x3A0A4A)),
    BgPreset("Neon Arcade", "🕹️", 1, cols(0x07001A, 0x3A00A0, 0x00F0FF)),
    BgPreset("Candy Land", "🍭", 3, cols(0xFF8AC8, 0xFFFFFF)),
    BgPreset("Galaxy", "🚀", 2, cols(0x6A00F4, 0x07001A)),
    BgPreset("Tropical Chai", "🍹", 0, cols(0x27E1FF, 0x39E58C, 0xFFD23F))
)

val OutBgs: List<BgPreset> = listOf(
    BgPreset("Casino Doom", "🎰", 0, cols(0x1A0004, 0x6B0014)),
    BgPreset("Rainy Day", "🌧️", 0, cols(0x2A3140, 0x0D1118)),
    BgPreset("Graveyard", "⚰️", 2, cols(0x3A4A3A, 0x050805)),
    BgPreset("Lava Pit", "🌋", 0, cols(0x2A0500, 0xFF3B00)),
    BgPreset("Toxic Loser", "☣️", 0, cols(0x0A1F00, 0x6BD300)),
    BgPreset("Ice Cold", "🧊", 0, cols(0xBFE9FF, 0x2A6FA8)),
    BgPreset("Warning Tape", "🚧", 3, cols(0xFFD23F, 0x111111)),
    BgPreset("Sad Blue", "😭", 0, cols(0x0B1A4A, 0x030818)),
    BgPreset("Burnt Toast", "🍞", 0, cols(0x3A1A05, 0x0A0402)),
    BgPreset("Midnight Chai", "☕", 2, cols(0x4A2A6A, 0x050208))
)

@Composable
fun PresetBg(p: BgPreset, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val m = maxOf(w, h)
        when (p.kind) {
            0 -> drawRect(Brush.verticalGradient(p.c))
            1 -> drawRect(Brush.linearGradient(p.c))
            2 -> drawRect(Brush.radialGradient(p.c, center = Offset(w / 2f, h * 0.35f), radius = m * 0.8f))
            5 -> drawRect(Brush.sweepGradient(p.c, center = Offset(w / 2f, h * 0.4f)))
            else -> {
                drawRect(p.c[0])
                val step = 56f
                rotate(45f, pivot = Offset(w / 2f, h / 2f)) {
                    var x = -m
                    var i = 0
                    while (x < m * 2f) {
                        if (i % 2 == 1) drawRect(p.c[1], Offset(x, -m), Size(step, m * 3f))
                        x += step
                        i++
                    }
                }
            }
        }
    }
}

/** Full-screen background of the WIN (win = true) or OUT screen: gallery photo, preset, or the theme. */
@Composable
fun ScreenBg(state: GameState, win: Boolean, modifier: Modifier = Modifier) {
    val C = LocalColors.current
    val idx = if (win) state.winBg else state.outBg
    val img = if (win) state.winBgImg else state.outBgImg
    val bmp = rememberBitmap(img)
    val list = if (win) WinBgs else OutBgs
    Box(modifier) {
        if (bmp != null) {
            Image(
                bitmap = bmp, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x44000000)))
        } else if (idx in list.indices) {
            PresetBg(list[idx], Modifier.fillMaxSize())
        } else {
            val colors = if (win) listOf(C(K.BG_TOP), C(K.BG_BOTTOM), C(K.BG_TOP)) else listOf(C(K.BG_TOP), C(K.BG_BOTTOM))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors)))
        }
    }
}
