# 100 Se Bachao! v2.2

Offline score tracker. Set the number of players (2 to 12) and the max score for each match. Reach it and you're OUT. Last player standing wins.
Kotlin + Jetpack Compose, minSdk 26 (Android 8.0+). No internet permission, no accounts.

> The first GitHub Actions run is the first real build of v2. If it fails, copy the red error lines and ask for a fix.

## Build the APK from your Android phone
1. github.com in Chrome (menu > Desktop site) > open your repo.
2. **Add file > Upload files** > choose the new `SeBachao.zip` (do NOT unzip). Same file name = it replaces the old ZIP. **Commit changes**.
3. **Actions** tab > wait for the green tick (about 5 to 10 min). If it does not start: Actions > Build APK > Run workflow.
4. Repo home > **Releases** > newest build > tap `100-Se-Bachao-release.apk`.

Install: open the APK, allow "Install unknown apps" if asked, tap Install. Installing over v1 keeps nothing from v1 (new storage), that is normal.

## What's new in v2.2
* **Player names**: the pencil icon is gone. Just tap the name to edit it.
* **Settings > CUSTOMIZE LAYOUT > CUSTOMIZE HEADER**: opens the real header. Tap an item, press and hold, then drag it anywhere. Drag the round handle (or the Size slider) to make it bigger or smaller. The big number (100), the SE BACHAO! text and both stickers move and resize separately. A slider changes the header height.
* **Settings > CUSTOMIZE LAYOUT > CUSTOMIZE WIN & OUT SCREENS**: opens the real WIN and OUT screens (switch with the two buttons). Move or resize every item (crown, photo, title, bubble, each sticker/GIF, scores box, buttons). 10 funny backgrounds for each screen, plus "my gallery photo" as background.
* **Settings > LOADING BAR STYLE**: 7 styles for the bar under every score (Classic, Candy Stripes, Neon Glow, Block Meter, Rainbow Danger, Battery, Hot Pulse). One tap changes all players.
* Everything is saved on the phone. Sounds, themes, colours, stickers and all v2.1 features are unchanged.
* **Fonts** are now downloaded with several mirrors and checked inside the finished APK, so the same fonts show on every phone. If a font cannot be downloaded the GitHub build stops with a red error instead of silently using the default font.

## What's new in v2.1
* **Fonts**: Bangers (big titles), Lilita One (buttons, labels, scores), Fredoka (body text). They are downloaded automatically by the GitHub build. For a local build run `./get_fonts.sh`.
* **Header** is taller and the two stickers are bigger, with a gap between them (tune the numbers in `HeaderSpec` in Screens.kt).
* **Player photo** on the cards is much bigger, with its own border colour.
* **Settings > THEME & COLORS**: 10 ready-made themes, and CUSTOMIZE COLORS to change about 40 colours one by one (header, round bar, player cards, photo border, History button + text, all buttons, panels, pop-ups...). Colours are saved on the phone.

## What's new in v2
* New Game screen: choose 2 to 12 players and any max score (50, 100, 150, 200 or custom 10 to 9999). Names/photos are kept.
* Header shows the big max score with a smaller SE BACHAO!, plus your stickers. Tap the header to change the banner photo.
* Tap a player's photo to change it; tap a name to rename it, any time.
* Settings: sound on/off, your own MP3 for round added / player OUT / winner (plays in full), Play preview, Reset.
* Settings > Edit all stickers: change each of the 6 stickers separately with any image or animated GIF.
* Dark Velvet Red cartoon theme, cards and chips in the background, animated OUT and WIN screens.

Everything is stored on the phone (JSON in SharedPreferences, copied files in app storage).
